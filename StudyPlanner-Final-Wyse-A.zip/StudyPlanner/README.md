# Study Planner — Course Project Final

Ashlie M Wyse · SDEV 264

This is the SDEV 264 final course project. Study Planner helps students keep assignment records, due dates, priorities, notes, and completion status. It continues the original four-activity design and adds final acceptance evidence for navigation, selected-record intents, and saved preferences.

## Four activities and their fragments

- MainActivity / AssignmentListFragment: assignment list, unfinished count, Add Assignment, Preferences, and Help buttons.
- AssignmentDetailsActivity / AssignmentDetailsFragment: title, course, due date, priority, notes, completion, Save, and Cancel. An explicit Intent passes the selected assignment ID, which loads the correct SQLite record. A new record uses ID -1.
- PreferencesActivity / PreferencesFragment: sort order, completed-record visibility, and default priority, saved together using Preferences DataStore.
- HelpActivity / HelpFragment: display-only, scrollable instructions explaining the app and every preference.

## Preference defaults and behavior

| Preference | Initial value | Effect |
|---|---|---|
| Sort order | Earliest due date first | Alternatively order High, Medium, Low, then by due date within each priority. |
| Show completed assignments | Off | Hide completed records without deleting them; switch on to view and edit them again. |
| Default priority | Medium | Prefill new assignments with Low, Medium, or High; never alter existing records. |

Tap Save Preferences to apply the complete form. Both changed and unchanged choices remain when revisiting the screen or restarting the app. Back cancels unsaved changes. An unsaved preference draft survives activity recreation.

Assignment data stays in SQLite. Required-field and calendar-date validation prevent invalid records. Saved edits update the selected record, Cancel does not save, and the list refreshes on return. The unfinished count includes all unfinished assignments regardless of the display preference. No API key or internet connection is needed to use the app.

## Run

Open this StudyPlanner directory in Android Studio, let Gradle sync, select app and an emulator, then click Run. The portable source excludes local SDK paths and IDE caches; Android Studio creates its own local.properties on import.

Version 1.0 (version code 5). Minimum Android 8.0 (API 26); compile/target API 35. Android Gradle Plugin 8.8.0 / Kotlin 2.1.0. Use an installed JDK 21 from any vendor and select it as the Gradle JDK in Android Studio. The included daemon criteria require JDK 21; Android Studio runtimes based on newer Java versions should not be selected for this Gradle version.

The debug build uses the isolated application ID `com.ashliewyse.studyplanner.final`. It installs alongside the original Study Planner app and keeps its test database and preferences separate. The production application ID and source namespace remain `com.ashliewyse.studyplanner`.

## Verification

Build and local checks:

```text
gradlew.bat :app:assembleDebug :app:testDebugUnitTest :app:lintDebug :app:assembleDebugAndroidTest
```

The existing unit tests cover required fields, calendar dates, sorting, filtering, and ties. Instrumented tests cover assignment editing and IDs, recreation, preferences, list behavior, priority defaults, and Help navigation. Instrumented tests reset the isolated debug application's test data.

FinalAcceptanceTest additionally verifies all four activities, the default preference values, changed and unchanged preferences on reopening, the selected assignment loaded using its Intent ID, saved edits, the date picker, preference effects on the Main list, data retained after activity relaunch, and Help navigation. It saves original emulator screenshots to the debug app's external files directory under final-evidence. The records shown are illustrative test data, not completion claims about other coursework.

Current build and test results are documented in the repository verification report. Screenshots are supplied individually in the Screenshots folder. Submit the Android Studio project ZIP and the individual screenshot files as requested by Canvas.
