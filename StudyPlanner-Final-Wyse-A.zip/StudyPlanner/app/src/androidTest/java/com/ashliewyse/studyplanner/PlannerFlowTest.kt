package com.ashliewyse.studyplanner

import android.content.Intent
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import android.content.Context
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.assertion.ViewAssertions.doesNotExist
import androidx.datastore.preferences.core.edit
import kotlinx.coroutines.runBlocking
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Before
import org.junit.After
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PlannerFlowTest {
    private val context get() = ApplicationProvider.getApplicationContext<Context>()
    @Before fun prepare() {
        context.deleteDatabase(AssignmentStore.DATABASE_NAME)
        runBlocking { context.plannerDataStore.edit { it.clear() } }
    }
    @After fun cleanUp() { context.deleteDatabase(AssignmentStore.DATABASE_NAME) }

    @Test fun addThenEditViaIntentAndRetainAfterRelaunch() {
        ActivityScenario.launch(MainActivity::class.java).use {
            onView(withId(R.id.add_assignment)).perform(click())
            onView(withId(R.id.assignment_title)).perform(replaceText("Course project"), closeSoftKeyboard())
            onView(withId(R.id.course_name)).perform(replaceText("SDEV 264"), closeSoftKeyboard())
            onView(withId(R.id.due_date)).perform(replaceText("2026-09-21"), closeSoftKeyboard())
            onView(withId(R.id.save_assignment)).perform(scrollTo(), click())
            onView(withText("Course project")).perform(scrollTo()).check(matches(isDisplayed())).perform(click())
            onView(withId(R.id.course_name)).check(matches(withText("SDEV 264")))
            onView(withId(R.id.assignment_title)).perform(replaceText("Revised project"), closeSoftKeyboard())
            onView(withId(R.id.completed)).perform(scrollTo(), click())
            onView(withId(R.id.save_assignment)).perform(scrollTo(), click())
            onView(withId(R.id.summary)).perform(scrollTo()).check(matches(withText("All caught up")))
        }
        ActivityScenario.launch(MainActivity::class.java).use {
            onView(withText("Revised project")).check(doesNotExist())
            onView(withText(R.string.hidden_title)).perform(scrollTo()).check(matches(isDisplayed()))
        }
        val saved = AssignmentStore(context).use { it.all() }
        assertEquals(1, saved.size)
        assertTrue(saved.single().completed)
    }

    @Test fun editingSelectedIdKeepsDraftAcrossRecreationAndCancelDoesNotSave() {
        val selectedId = AssignmentStore(context).use {
            it.save(Assignment(title = "First", course = "One", dueDate = "2026-09-21"))
            it.save(Assignment(title = "Second", course = "Two", dueDate = "2026-09-22"))
        }
        val intent = Intent(context, AssignmentDetailsActivity::class.java)
            .putExtra(AssignmentDetailsActivity.EXTRA_ASSIGNMENT_ID, selectedId)
        ActivityScenario.launch<AssignmentDetailsActivity>(intent).use { scenario ->
            onView(withId(R.id.assignment_title)).check(matches(withText("Second")))
            onView(withId(R.id.assignment_title)).perform(replaceText("Unsaved draft"), closeSoftKeyboard())
            scenario.recreate()
            onView(withId(R.id.assignment_title)).check(matches(withText("Unsaved draft")))
            onView(withId(R.id.cancel)).perform(scrollTo(), click())
        }
        assertEquals("Second", AssignmentStore(context).use { it.find(selectedId)!!.title })
    }

    @Test fun invalidInputCannotCreateARecord() {
        ActivityScenario.launch(AssignmentDetailsActivity::class.java).use {
            onView(withId(R.id.save_assignment)).perform(scrollTo(), click())
            onView(withText(R.string.title_required)).check(matches(isDisplayed()))
            assertTrue(AssignmentStore(context).use { it.all().isEmpty() })
        }
    }
}

