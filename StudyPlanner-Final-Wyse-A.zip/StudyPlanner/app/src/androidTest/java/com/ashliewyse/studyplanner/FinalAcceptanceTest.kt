package com.ashliewyse.studyplanner

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import android.view.View
import android.widget.DatePicker
import android.widget.LinearLayout
import android.widget.TextView
import androidx.datastore.preferences.core.edit
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.espresso.Espresso
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.NoMatchingViewException
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.UiController
import androidx.test.espresso.ViewAction
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.hamcrest.Matcher

/** Exercises the complete final project workflow and saves unmodified device screenshots. */
@RunWith(AndroidJUnit4::class)
class FinalAcceptanceTest {
    private val context get() = ApplicationProvider.getApplicationContext<Context>()

    @Before fun isolatedTestData() = runBlocking {
        check(context.packageName.endsWith(".final"))
        context.deleteDatabase(AssignmentStore.DATABASE_NAME)
        context.plannerDataStore.edit { it.clear() }
        Unit
    }

    private fun eventually(assertion: () -> Unit) {
        val deadline = SystemClock.uptimeMillis() + 8000
        while (true) {
            try { assertion(); return } catch (failure: AssertionError) {
                if (SystemClock.uptimeMillis() >= deadline) throw failure
                SystemClock.sleep(50)
            } catch (failure: NoMatchingViewException) {
                // Preference writes finish asynchronously, then the next activity appears.
                if (SystemClock.uptimeMillis() >= deadline) throw failure
                SystemClock.sleep(50)
            }
        }
    }

    private fun preferencesLoaded() = eventually {
        onView(withId(R.id.save_preferences)).check(matches(isEnabled()))
    }

    private fun mainReady() = eventually {
        onView(withId(R.id.add_assignment)).check(matches(isDisplayed()))
    }

    private fun selectProjectDate() = object : ViewAction {
        override fun getConstraints(): Matcher<View> = isAssignableFrom(DatePicker::class.java)
        override fun getDescription() = "Select October 17, 2026 in the date picker"
        override fun perform(uiController: UiController, view: View) {
            (view as DatePicker).updateDate(2026, 9, 17)
            uiController.loopMainThreadUntilIdle()
        }
    }

    private fun screenshot(name: String) {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        instrumentation.waitForIdleSync()
        // Let focus-label, switch, and scrolling animations settle before capturing pixels.
        instrumentation.uiAutomation.waitForIdle(500, 5000)
        val image = checkNotNull(instrumentation.uiAutomation.takeScreenshot())
        val directory = checkNotNull(context.getExternalFilesDir("final-evidence"))
        check(directory.exists() || directory.mkdirs())
        FileOutputStream(File(directory, "$name.png")).use {
            check(image.compress(Bitmap.CompressFormat.PNG, 100, it))
        }
        image.recycle()
    }

    private fun titles(scenario: ActivityScenario<MainActivity>): List<String> {
        var result = emptyList<String>()
        scenario.onActivity { activity ->
            val list = activity.findViewById<LinearLayout>(R.id.assignment_list)
            result = (0 until list.childCount).map {
                list.getChildAt(it).findViewById<TextView>(R.id.row_title).text.toString()
            }
        }
        return result
    }

    @Test fun fourActivitiesRetainPreferencesAndPassSelectedAssignmentWithEvidence() {
        ActivityScenario.launch(MainActivity::class.java).use { main ->
            onView(withId(R.id.add_assignment)).check(matches(isDisplayed()))
            screenshot("01-Main-Activity")

            onView(withId(R.id.open_preferences)).perform(scrollTo(), click())
            preferencesLoaded()
            onView(withId(R.id.sort_due)).check(matches(isChecked()))
            onView(withId(R.id.show_completed)).check(matches(isNotChecked()))
            onView(withId(R.id.default_medium)).check(matches(isChecked()))
            screenshot("02-Preferences-Defaults")
            onView(withId(R.id.show_completed)).perform(scrollTo(), click())
            onView(withId(R.id.default_high)).perform(scrollTo(), click())
            onView(withId(R.id.save_preferences)).perform(scrollTo(), click())
            mainReady()

            onView(withId(R.id.open_preferences)).perform(scrollTo(), click())
            preferencesLoaded()
            onView(withId(R.id.sort_due)).check(matches(isChecked()))
            onView(withId(R.id.show_completed)).check(matches(isChecked()))
            onView(withId(R.id.default_high)).check(matches(isChecked()))
            screenshot("03-Preferences-Reopened-Saved-Choices")
            Espresso.pressBack()
            mainReady()

            onView(withId(R.id.add_assignment)).perform(scrollTo(), click())
            eventually { onView(withId(R.id.priority)).check(matches(withSpinnerText("High"))) }
            onView(withId(R.id.assignment_title)).perform(replaceText("Module 8 Course Project Final"), closeSoftKeyboard())
            onView(withId(R.id.course_name)).perform(replaceText("SDEV 264"), closeSoftKeyboard())
            onView(withId(R.id.choose_date)).perform(scrollTo(), click())
            onView(isAssignableFrom(DatePicker::class.java)).perform(selectProjectDate())
            onView(withId(android.R.id.button1)).perform(click())
            onView(withId(R.id.due_date)).check(matches(withText("2026-10-17")))
            onView(withId(R.id.notes)).perform(scrollTo(), replaceText("Test four activities and saved preferences."), closeSoftKeyboard())
            onView(withId(R.id.assignment_title)).perform(scrollTo())
            screenshot("04-Assignment-Input-And-Default-Priority")
            onView(withId(R.id.save_assignment)).perform(scrollTo(), click())
            mainReady()
            eventually { assertEquals(listOf("Module 8 Course Project Final"), titles(main)) }
            onView(withId(R.id.summary)).check(matches(withText("1 unfinished assignment")))
            screenshot("05-Main-Saved-Assignment-Output")

            onView(withText("Module 8 Course Project Final")).perform(scrollTo(), click())
            onView(withId(R.id.assignment_title)).check(matches(withText("Module 8 Course Project Final")))
            onView(withId(R.id.course_name)).check(matches(withText("SDEV 264")))
            onView(withId(R.id.due_date)).check(matches(withText("2026-10-17")))
            onView(withId(R.id.priority)).check(matches(withSpinnerText("High")))
            screenshot("06-Secondary-Activity-Selected-Record-From-Intent")
            onView(withId(R.id.assignment_title)).perform(replaceText("Study Planner Final - tested"), closeSoftKeyboard())
            onView(withId(R.id.save_assignment)).perform(scrollTo(), click())
            mainReady()
            eventually { assertEquals(listOf("Study Planner Final - tested"), titles(main)) }

            onView(withId(R.id.add_assignment)).perform(scrollTo(), click())
            eventually { onView(withId(R.id.save_assignment)).check(matches(isEnabled())) }
            onView(withId(R.id.assignment_title)).perform(replaceText("Compose with Views Lab"), closeSoftKeyboard())
            onView(withId(R.id.course_name)).perform(replaceText("SDEV 264"), closeSoftKeyboard())
            onView(withId(R.id.due_date)).perform(replaceText("2026-10-10"), closeSoftKeyboard())
            onView(withId(R.id.priority)).perform(scrollTo(), click())
            onView(withText("Low")).perform(click())
            onView(withId(R.id.save_assignment)).perform(scrollTo(), click())
            mainReady()

            onView(withId(R.id.add_assignment)).perform(scrollTo(), click())
            eventually { onView(withId(R.id.save_assignment)).check(matches(isEnabled())) }
            onView(withId(R.id.assignment_title)).perform(replaceText("Unit 8 Quiz Evidence"), closeSoftKeyboard())
            onView(withId(R.id.course_name)).perform(replaceText("SDEV 264"), closeSoftKeyboard())
            onView(withId(R.id.due_date)).perform(replaceText("2026-10-09"), closeSoftKeyboard())
            onView(withId(R.id.priority)).perform(scrollTo(), click())
            onView(withText("Medium")).perform(click())
            onView(withId(R.id.completed)).perform(scrollTo(), click())
            onView(withId(R.id.save_assignment)).perform(scrollTo(), click())
            mainReady()
            eventually { assertEquals(listOf("Unit 8 Quiz Evidence", "Compose with Views Lab", "Study Planner Final - tested"), titles(main)) }
            onView(withId(R.id.summary)).perform(scrollTo()).check(matches(withText("2 unfinished assignments")))
            screenshot("07-Main-Due-Date-Order-And-Completed-Shown")

            onView(withId(R.id.open_preferences)).perform(scrollTo(), click())
            preferencesLoaded()
            onView(withId(R.id.sort_priority)).perform(scrollTo(), click())
            onView(withId(R.id.show_completed)).perform(scrollTo(), click())
            onView(withId(R.id.default_high)).check(matches(isChecked()))
            screenshot("08-Preferences-Changed-Sort-And-Filter-Input")
            onView(withId(R.id.save_preferences)).perform(scrollTo(), click())
            mainReady()
            eventually { assertEquals(listOf("Study Planner Final - tested", "Compose with Views Lab"), titles(main)) }
            onView(withId(R.id.summary)).perform(scrollTo()).check(matches(withText("2 unfinished assignments")))
            screenshot("09-Main-Preference-Effects-Output")
        }

        // A new activity launch must reload persisted records and preferences.
        ActivityScenario.launch(MainActivity::class.java).use { reopened ->
            eventually { assertEquals(listOf("Study Planner Final - tested", "Compose with Views Lab"), titles(reopened)) }
            assertEquals(3, AssignmentStore(context).use { it.all().size })
            screenshot("10-Main-Relaunched-With-Saved-Data")
            onView(withId(R.id.open_preferences)).perform(scrollTo(), click())
            preferencesLoaded()
            onView(withId(R.id.sort_priority)).check(matches(isChecked()))
            onView(withId(R.id.show_completed)).check(matches(isNotChecked()))
            onView(withId(R.id.default_high)).check(matches(isChecked()))
            screenshot("11-Preferences-Retained-After-Relaunch")
            Espresso.pressBack()
            mainReady()
            onView(withId(R.id.open_help)).perform(scrollTo(), click())
            onView(withText(R.string.help_purpose_title)).check(matches(isDisplayed()))
            screenshot("12-Help-Opened-From-Main")
            onView(withText(R.string.help_saving)).perform(scrollTo()).check(matches(isDisplayed()))
            screenshot("13-Help-Explains-Preferences")
            Espresso.pressBack()
            mainReady()
            eventually { assertEquals(listOf("Study Planner Final - tested", "Compose with Views Lab"), titles(reopened)) }
            screenshot("14-Returned-To-Main")
        }
    }
}
