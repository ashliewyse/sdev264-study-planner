package com.ashliewyse.studyplanner

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.widget.LinearLayout
import android.widget.TextView
import androidx.datastore.preferences.core.edit
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.espresso.Espresso
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PreferencesFlowTest {
    private val context get() = ApplicationProvider.getApplicationContext<Context>()

    @Before fun prepare() = runBlocking {
        context.deleteDatabase(AssignmentStore.DATABASE_NAME)
        context.plannerDataStore.edit { it.clear() }
        Unit
    }
    @After fun cleanUp() = runBlocking {
        context.deleteDatabase(AssignmentStore.DATABASE_NAME)
        context.plannerDataStore.edit { it.clear() }
        Unit
    }

    private fun eventually(assertion: () -> Unit) {
        val deadline = SystemClock.uptimeMillis() + 5000
        while (true) {
            try { assertion(); return } catch (failure: AssertionError) {
                if (SystemClock.uptimeMillis() >= deadline) throw failure
                SystemClock.sleep(50)
            }
        }
    }
    private fun awaitPreferences() = eventually {
        onView(withId(R.id.save_preferences)).check(matches(isEnabled()))
    }

    @Test fun defaultsThenPartialChangesSurviveReopeningWithUnchangedSort() {
        assertEquals(PlannerSettings(), runBlocking { PlannerPreferences(context).settings.first() })
        ActivityScenario.launch(MainActivity::class.java).use {
            onView(withId(R.id.open_preferences)).perform(scrollTo(), click())
            awaitPreferences()
            onView(withId(R.id.sort_due)).check(matches(isChecked()))
            onView(withId(R.id.show_completed)).check(matches(isNotChecked()))
            onView(withId(R.id.default_medium)).check(matches(isChecked()))
            onView(withId(R.id.show_completed)).perform(scrollTo(), click())
            onView(withId(R.id.default_high)).perform(scrollTo(), click())
            onView(withId(R.id.save_preferences)).perform(scrollTo(), click())
            eventually {
                assertEquals(PlannerSettings(showCompleted = true, defaultPriority = "High"),
                    runBlocking { PlannerPreferences(context).settings.first() })
            }
        }
        ActivityScenario.launch(PreferencesActivity::class.java).use {
            awaitPreferences()
            onView(withId(R.id.sort_due)).check(matches(isChecked()))
            onView(withId(R.id.show_completed)).check(matches(isChecked()))
            onView(withId(R.id.default_high)).check(matches(isChecked()))
        }
    }

    @Test fun unsavedDraftSurvivesRecreationAndBackDoesNotCommit() {
        ActivityScenario.launch(PreferencesActivity::class.java).use { scenario ->
            awaitPreferences()
            onView(withId(R.id.sort_priority)).perform(scrollTo(), click())
            onView(withId(R.id.default_low)).perform(scrollTo(), click())
            scenario.recreate()
            awaitPreferences()
            onView(withId(R.id.sort_priority)).check(matches(isChecked()))
            onView(withId(R.id.default_low)).check(matches(isChecked()))
            Espresso.pressBackUnconditionally()
        }
        assertEquals(PlannerSettings(), runBlocking { PlannerPreferences(context).settings.first() })
    }

    @Test fun savedPreferencesChangeMainListFilterAndOrder() {
        AssignmentStore(context).use {
            it.save(Assignment(title = "Soon", course = "One", dueDate = "2026-09-28", priority = "Low"))
            it.save(Assignment(title = "Important", course = "Two", dueDate = "2026-10-02", priority = "High"))
            it.save(Assignment(title = "Done", course = "One", dueDate = "2026-09-27", completed = true))
        }
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            fun titles(): List<String> {
                var result = emptyList<String>()
                scenario.onActivity { activity ->
                    val list = activity.findViewById<LinearLayout>(R.id.assignment_list)
                    result = (0 until list.childCount).map { list.getChildAt(it).findViewById<TextView>(R.id.row_title).text.toString() }
                }
                return result
            }
            eventually { assertEquals(listOf("Soon", "Important"), titles()) }
            onView(withId(R.id.open_preferences)).perform(scrollTo(), click())
            awaitPreferences()
            onView(withId(R.id.sort_priority)).perform(scrollTo(), click())
            onView(withId(R.id.show_completed)).perform(scrollTo(), click())
            onView(withId(R.id.save_preferences)).perform(scrollTo(), click())
            eventually { assertEquals(listOf("Important", "Done", "Soon"), titles()) }
            onView(withId(R.id.summary)).perform(scrollTo()).check(matches(withText("2 unfinished assignments")))
        }
    }

    @Test fun newDefaultDoesNotOverwriteExistingAssignmentAndHelpOpensFromMain() {
        runBlocking { PlannerPreferences(context).save(PlannerSettings(defaultPriority = "High")) }
        val id = AssignmentStore(context).use {
            it.save(Assignment(title = "Existing", course = "One", dueDate = "2026-09-28", priority = "Low"))
        }
        ActivityScenario.launch(MainActivity::class.java).use {
            onView(withId(R.id.open_help)).perform(scrollTo(), click())
            onView(withText(R.string.help_purpose_title)).check(matches(isDisplayed()))
            onView(withText(R.string.help_saving)).perform(scrollTo()).check(matches(isDisplayed()))
            Espresso.pressBack()
            onView(withId(R.id.add_assignment)).perform(scrollTo(), click())
            eventually { onView(withId(R.id.priority)).check(matches(withSpinnerText("High"))) }
            Espresso.pressBack()
        }
        val intent = Intent(context, AssignmentDetailsActivity::class.java)
            .putExtra(AssignmentDetailsActivity.EXTRA_ASSIGNMENT_ID, id)
        ActivityScenario.launch<AssignmentDetailsActivity>(intent).use {
            onView(withId(R.id.assignment_title)).check(matches(withText("Existing")))
            onView(withId(R.id.priority)).check(matches(withSpinnerText("Low")))
        }
    }
}
