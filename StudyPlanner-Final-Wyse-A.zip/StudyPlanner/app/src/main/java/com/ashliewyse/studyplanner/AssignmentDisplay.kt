package com.ashliewyse.studyplanner

/** Filtering changes only the display; completed records stay in SQLite. */
fun displayAssignments(assignments: List<Assignment>, settings: PlannerSettings): List<Assignment> {
    val dueOrder = compareBy<Assignment> { it.dueDate }.thenBy { it.id }
    val comparator = if (settings.sortOrder == SortOrder.PRIORITY) {
        compareBy<Assignment> { when (it.priority) { "High" -> 0; "Medium" -> 1; else -> 2 } }
            .then(dueOrder)
    } else dueOrder
    return assignments.filter { settings.showCompleted || !it.completed }.sortedWith(comparator)
}
