package com.ashliewyse.studyplanner

import android.os.Bundle
import com.google.android.material.appbar.MaterialToolbar

class PreferencesActivity : PlannerActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        findViewById<MaterialToolbar>(R.id.toolbar).apply {
            setTitle(R.string.preferences)
            setNavigationIcon(R.drawable.ic_back)
            setNavigationContentDescription(R.string.go_back)
            setNavigationOnClickListener { finish() }
        }
        if (savedInstanceState == null) supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, PreferencesFragment()).commit()
    }
}
