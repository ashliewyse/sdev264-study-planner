package com.ashliewyse.studyplanner

import android.os.Bundle
import android.view.View
import android.widget.RadioGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.switchmaterial.SwitchMaterial
import java.io.IOException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class PreferencesFragment : Fragment(R.layout.fragment_preferences) {
    private var loaded = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val sort = view.findViewById<RadioGroup>(R.id.sort_order)
        val show = view.findViewById<SwitchMaterial>(R.id.show_completed)
        val priority = view.findViewById<RadioGroup>(R.id.default_priority)
        val save = view.findViewById<View>(R.id.save_preferences)
        val repository = PlannerPreferences(requireContext())
        fun enable(enabled: Boolean) {
            save.isEnabled = enabled
            show.isEnabled = enabled
            for (i in 0 until sort.childCount) sort.getChildAt(i).isEnabled = enabled
            for (i in 0 until priority.childCount) priority.getChildAt(i).isEnabled = enabled
        }
        enable(false)
        viewLifecycleOwner.lifecycleScope.launch {
            val settings = repository.settings.first()
            // Restore an unsaved draft on recreation instead of replacing it with stored values.
            val draft = savedInstanceState?.takeIf { it.getBoolean("loaded") }
            sort.check(draft?.getInt("sort") ?: if (settings.sortOrder == SortOrder.PRIORITY) R.id.sort_priority else R.id.sort_due)
            show.isChecked = draft?.getBoolean("show") ?: settings.showCompleted
            priority.check(draft?.getInt("priority") ?: when (settings.defaultPriority) {
                "Low" -> R.id.default_low; "High" -> R.id.default_high; else -> R.id.default_medium
            })
            loaded = true
            enable(true)
        }
        save.setOnClickListener {
            val settings = PlannerSettings(
                sortOrder = if (sort.checkedRadioButtonId == R.id.sort_priority) SortOrder.PRIORITY else SortOrder.DUE_DATE,
                showCompleted = show.isChecked,
                defaultPriority = when (priority.checkedRadioButtonId) {
                    R.id.default_low -> "Low"; R.id.default_high -> "High"; else -> "Medium"
                }
            )
            enable(false)
            viewLifecycleOwner.lifecycleScope.launch {
                try {
                    repository.save(settings)
                    Toast.makeText(requireContext(), R.string.preferences_saved, Toast.LENGTH_SHORT).show()
                    requireActivity().finish()
                } catch (_: IOException) {
                    enable(true)
                    Toast.makeText(requireContext(), R.string.preferences_failed, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        view?.let { screen ->
            outState.putBoolean("loaded", loaded)
            outState.putInt("sort", screen.findViewById<RadioGroup>(R.id.sort_order).checkedRadioButtonId)
            outState.putBoolean("show", screen.findViewById<SwitchMaterial>(R.id.show_completed).isChecked)
            outState.putInt("priority", screen.findViewById<RadioGroup>(R.id.default_priority).checkedRadioButtonId)
        }
    }
}
