package com.ashliewyse.studyplanner

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

class AssignmentListFragment : Fragment(R.layout.fragment_main) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.findViewById<View>(R.id.add_assignment).setOnClickListener { openAssignment(NEW_ASSIGNMENT) }
        view.findViewById<View>(R.id.open_preferences).setOnClickListener {
            startActivity(Intent(requireContext(), PreferencesActivity::class.java))
        }
        view.findViewById<View>(R.id.open_help).setOnClickListener {
            startActivity(Intent(requireContext(), HelpActivity::class.java))
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.RESUMED) {
                PlannerPreferences(requireContext()).settings.collect { settings -> render(settings) }
            }
        }
    }
    private fun render(settings: PlannerSettings) {
        // Refresh records and settings whenever the user returns to the main activity.
        val assignments = AssignmentStore(requireContext()).use { it.all() }
        val visible = displayAssignments(assignments, settings)
        val pending = assignments.count { !it.completed }
        val screen = requireView()
        screen.findViewById<TextView>(R.id.summary).text = if (pending == 0 && assignments.isNotEmpty())
            getString(R.string.no_pending) else resources.getQuantityString(R.plurals.unfinished, pending, pending)
        screen.findViewById<View>(R.id.empty_state).visibility = if (visible.isEmpty()) View.VISIBLE else View.GONE
        screen.findViewById<TextView>(R.id.empty_title).setText(if (assignments.isEmpty()) R.string.empty_title else R.string.hidden_title)
        screen.findViewById<TextView>(R.id.empty_message).setText(if (assignments.isEmpty()) R.string.empty_message else R.string.hidden_message)
        screen.findViewById<TextView>(R.id.list_hint).text = getString(R.string.list_preference_hint,
            getString(if (settings.sortOrder == SortOrder.PRIORITY) R.string.priority_first else R.string.due_first),
            getString(if (settings.showCompleted) R.string.completed_shown else R.string.completed_hidden))
        val list = screen.findViewById<LinearLayout>(R.id.assignment_list)
        list.removeAllViews()
        visible.forEach { assignment ->
            val card = layoutInflater.inflate(R.layout.item_assignment, list, false)
            card.findViewById<TextView>(R.id.row_title).text = assignment.title
            val date = LocalDate.parse(assignment.dueDate).format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))
            card.findViewById<TextView>(R.id.row_course).text = getString(R.string.row_course_date, assignment.course, date)
            card.findViewById<TextView>(R.id.row_status).text = getString(R.string.row_status, assignment.priority,
                getString(if (assignment.completed) R.string.completed else R.string.unfinished_status))
            card.setOnClickListener { openAssignment(assignment.id) }
            list.addView(card)
        }
    }
    private fun openAssignment(id: Long) {
        // An explicit Intent identifies the second Activity and passes the selected record's ID.
        startActivity(Intent(requireContext(), AssignmentDetailsActivity::class.java)
            .putExtra(AssignmentDetailsActivity.EXTRA_ASSIGNMENT_ID, id))
    }
}
