package com.ashliewyse.studyplanner

import androidx.fragment.app.Fragment

/** Display-only instructions; navigation is supplied by the hosting activity. */
class HelpFragment : Fragment(R.layout.fragment_help)
