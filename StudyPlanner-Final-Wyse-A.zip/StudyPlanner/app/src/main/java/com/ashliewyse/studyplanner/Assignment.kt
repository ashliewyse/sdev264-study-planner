package com.ashliewyse.studyplanner

import java.time.LocalDate
import java.time.format.DateTimeParseException

data class Assignment(
    val id: Long = NEW_ASSIGNMENT,
    val title: String,
    val course: String,
    val dueDate: String,
    val priority: String = "Medium",
    val notes: String = "",
    val completed: Boolean = false
)

const val NEW_ASSIGNMENT = -1L

object AssignmentValidator {
    fun isValidDate(value: String): Boolean {
        if (!value.matches(Regex("[0-9]{4}-[0-9]{2}-[0-9]{2}"))) return false
        return try { LocalDate.parse(value).year in 1..9999 } catch (_: DateTimeParseException) { false }
    }
    fun isValid(assignment: Assignment): Boolean = assignment.title.isNotBlank() &&
        assignment.course.isNotBlank() && isValidDate(assignment.dueDate) &&
        assignment.priority in listOf("Low", "Medium", "High")
}
