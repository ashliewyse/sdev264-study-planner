package com.ashliewyse.studyplanner

import android.os.Bundle
import com.google.android.material.appbar.MaterialToolbar

class MainActivity : PlannerActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        findViewById<MaterialToolbar>(R.id.toolbar).setTitle(R.string.app_name)
        if (savedInstanceState == null) supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, AssignmentListFragment()).commit()
    }
}
