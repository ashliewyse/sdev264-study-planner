package com.ashliewyse.studyplanner

import android.app.DatePickerDialog
import android.database.SQLException
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import com.google.android.material.textfield.TextInputLayout
import java.time.LocalDate

class AssignmentDetailsFragment : Fragment(R.layout.fragment_details) {
    private val assignmentId: Long get() = requireArguments()
        .getLong(AssignmentDetailsActivity.EXTRA_ASSIGNMENT_ID, NEW_ASSIGNMENT)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val title = view.findViewById<EditText>(R.id.assignment_title)
        val course = view.findViewById<EditText>(R.id.course_name)
        val date = view.findViewById<EditText>(R.id.due_date)
        val priority = view.findViewById<Spinner>(R.id.priority)
        val notes = view.findViewById<EditText>(R.id.notes)
        val completed = view.findViewById<CheckBox>(R.id.completed)

        // Populate once. Android restores unsaved form input on rotation using the view IDs.
        if (savedInstanceState == null) {
            if (assignmentId == NEW_ASSIGNMENT) {
                val save = view.findViewById<View>(R.id.save_assignment)
                priority.isEnabled = false
                save.isEnabled = false
                viewLifecycleOwner.lifecycleScope.launch {
                    val settings = PlannerPreferences(requireContext()).settings.first()
                    priority.setSelection(resources.getStringArray(R.array.priorities).indexOf(settings.defaultPriority))
                    priority.isEnabled = true
                    save.isEnabled = true
                }
            } else {
                val existing = AssignmentStore(requireContext()).use { it.find(assignmentId) }
                if (existing == null) {
                    Toast.makeText(requireContext(), R.string.missing_assignment, Toast.LENGTH_LONG).show()
                    requireActivity().finish()
                    return
                }
                title.setText(existing.title); course.setText(existing.course); date.setText(existing.dueDate)
                priority.setSelection(resources.getStringArray(R.array.priorities).indexOf(existing.priority).coerceAtLeast(0))
                notes.setText(existing.notes); completed.isChecked = existing.completed
            }
        }
        view.findViewById<View>(R.id.choose_date).setOnClickListener {
            val selected = date.text.toString().let { if (AssignmentValidator.isValidDate(it)) LocalDate.parse(it) else LocalDate.now() }
            DatePickerDialog(requireContext(), { _, year, month, day ->
                date.setText(LocalDate.of(year, month + 1, day).toString())
            }, selected.year, selected.monthValue - 1, selected.dayOfMonth).show()
        }
        view.findViewById<View>(R.id.cancel).setOnClickListener { requireActivity().finish() }
        view.findViewById<View>(R.id.save_assignment).setOnClickListener {
            val assignment = Assignment(assignmentId, title.text.toString().trim(), course.text.toString().trim(),
                date.text.toString().trim(), priority.selectedItem.toString(), notes.text.toString().trim(), completed.isChecked)
            view.findViewById<TextInputLayout>(R.id.title_layout).error = if (assignment.title.isBlank()) getString(R.string.title_required) else null
            view.findViewById<TextInputLayout>(R.id.course_layout).error = if (assignment.course.isBlank()) getString(R.string.course_required) else null
            view.findViewById<TextInputLayout>(R.id.date_layout).error = if (!AssignmentValidator.isValidDate(assignment.dueDate)) getString(R.string.date_required) else null
            if (!AssignmentValidator.isValid(assignment)) {
                when { assignment.title.isBlank() -> title.requestFocus()
                    assignment.course.isBlank() -> course.requestFocus()
                    else -> date.requestFocus() }
                return@setOnClickListener
            }
            try {
                AssignmentStore(requireContext()).use { it.save(assignment) }
                requireActivity().finish()
            } catch (_: SQLException) {
                Toast.makeText(requireContext(), R.string.save_failed, Toast.LENGTH_LONG).show()
            } catch (_: IllegalStateException) {
                Toast.makeText(requireContext(), R.string.save_failed, Toast.LENGTH_LONG).show()
            }
        }
    }
}
