package com.ashliewyse.studyplanner

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.IOException
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

// One DataStore instance per file for the entire application.
internal val Context.plannerDataStore by preferencesDataStore(name = "planner_preferences")

enum class SortOrder { DUE_DATE, PRIORITY }

data class PlannerSettings(
    val sortOrder: SortOrder = SortOrder.DUE_DATE,
    val showCompleted: Boolean = false,
    val defaultPriority: String = "Medium"
)

class PlannerPreferences(context: Context) {
    private val dataStore = context.applicationContext.plannerDataStore
    val settings = dataStore.data.catch { error ->
        if (error is IOException) emit(emptyPreferences()) else throw error
    }.map { values ->
        PlannerSettings(
            sortOrder = if (values[SORT] == SortOrder.PRIORITY.name) SortOrder.PRIORITY else SortOrder.DUE_DATE,
            showCompleted = values[SHOW_COMPLETED] ?: false,
            defaultPriority = values[DEFAULT_PRIORITY]?.takeIf { it in listOf("Low", "Medium", "High") } ?: "Medium"
        )
    }

    // Save the complete form atomically, retaining fields the user did not change.
    suspend fun save(settings: PlannerSettings) {
        require(settings.defaultPriority in listOf("Low", "Medium", "High"))
        dataStore.edit { values ->
            values[SORT] = settings.sortOrder.name
            values[SHOW_COMPLETED] = settings.showCompleted
            values[DEFAULT_PRIORITY] = settings.defaultPriority
        }
    }

    private companion object {
        val SORT = stringPreferencesKey("sort_order")
        val SHOW_COMPLETED = booleanPreferencesKey("show_completed")
        val DEFAULT_PRIORITY = stringPreferencesKey("default_priority")
    }
}
