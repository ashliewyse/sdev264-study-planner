package com.ashliewyse.studyplanner

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Local records survive activity changes and app restarts. No account or internet needed. */
class AssignmentStore(context: Context) : SQLiteOpenHelper(context.applicationContext, DATABASE_NAME, null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE assignments (
            _id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL, course TEXT NOT NULL, due_date TEXT NOT NULL,
            priority TEXT NOT NULL, notes TEXT NOT NULL, completed INTEGER NOT NULL DEFAULT 0
        )""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun all(): List<Assignment> = readableDatabase.query(
        "assignments", null, null, null, null, null, "due_date ASC, _id ASC"
    ).use { cursor -> buildList { while (cursor.moveToNext()) add(cursor.readAssignment()) } }

    fun find(id: Long): Assignment? = readableDatabase.query(
        "assignments", null, "_id = ?", arrayOf(id.toString()), null, null, null
    ).use { if (it.moveToFirst()) it.readAssignment() else null }

    fun save(assignment: Assignment): Long {
        require(AssignmentValidator.isValid(assignment))
        val values = ContentValues().apply {
            put("title", assignment.title.trim()); put("course", assignment.course.trim())
            put("due_date", assignment.dueDate); put("priority", assignment.priority)
            put("notes", assignment.notes.trim()); put("completed", if (assignment.completed) 1 else 0)
        }
        return if (assignment.id == NEW_ASSIGNMENT) writableDatabase.insertOrThrow("assignments", null, values)
        else {
            check(writableDatabase.update("assignments", values, "_id = ?", arrayOf(assignment.id.toString())) == 1)
            assignment.id
        }
    }

    private fun Cursor.readAssignment() = Assignment(
        id = getLong(getColumnIndexOrThrow("_id")),
        title = getString(getColumnIndexOrThrow("title")), course = getString(getColumnIndexOrThrow("course")),
        dueDate = getString(getColumnIndexOrThrow("due_date")), priority = getString(getColumnIndexOrThrow("priority")),
        notes = getString(getColumnIndexOrThrow("notes")), completed = getInt(getColumnIndexOrThrow("completed")) == 1
    )
    companion object { const val DATABASE_NAME = "study_planner.db" }
}
