package com.ashliewyse.studyplanner

import android.os.Bundle
import com.google.android.material.appbar.MaterialToolbar

class AssignmentDetailsActivity : PlannerActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val assignmentId = intent.getLongExtra(EXTRA_ASSIGNMENT_ID, NEW_ASSIGNMENT)
        findViewById<MaterialToolbar>(R.id.toolbar).apply {
            setTitle(if (assignmentId == NEW_ASSIGNMENT) R.string.add_assignment else R.string.edit_assignment)
            setNavigationIcon(R.drawable.ic_back)
            setNavigationContentDescription(R.string.go_back)
            setNavigationOnClickListener { finish() }
        }
        if (savedInstanceState == null) {
            val fragment = AssignmentDetailsFragment().apply {
                arguments = Bundle().apply { putLong(EXTRA_ASSIGNMENT_ID, assignmentId) }
            }
            supportFragmentManager.beginTransaction().replace(R.id.fragment_container, fragment).commit()
        }
    }
    companion object { const val EXTRA_ASSIGNMENT_ID = "com.ashliewyse.studyplanner.ASSIGNMENT_ID" }
}
