package com.ashliewyse.studyplanner

import android.os.Bundle
import com.google.android.material.appbar.MaterialToolbar

class HelpActivity : PlannerActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        findViewById<MaterialToolbar>(R.id.toolbar).apply {
            setTitle(R.string.help)
            setNavigationIcon(R.drawable.ic_back)
            setNavigationContentDescription(R.string.go_back)
            setNavigationOnClickListener { finish() }
        }
        if (savedInstanceState == null) supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, HelpFragment()).commit()
    }
}
