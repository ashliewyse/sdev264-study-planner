package com.ashliewyse.studyplanner

import org.junit.Assert.*
import org.junit.Test

class AssignmentDisplayTest {
    private val assignments = listOf(
        Assignment(1, "Soon", "One", "2026-09-28", "Low"),
        Assignment(2, "Important", "Two", "2026-10-02", "High"),
        Assignment(3, "Done", "One", "2026-09-27", "Medium", completed = true),
        Assignment(4, "Earlier high", "Two", "2026-09-30", "High")
    )

    @Test fun defaultsShowUnfinishedByDueDateWithoutDeletingRecords() {
        assertEquals(listOf(1L, 4L, 2L), displayAssignments(assignments, PlannerSettings()).map { it.id })
        assertEquals(4, assignments.size)
    }

    @Test fun prioritySortingUsesDueDateToBreakTiesAndCanShowCompleted() {
        val settings = PlannerSettings(sortOrder = SortOrder.PRIORITY, showCompleted = true)
        assertEquals(listOf(4L, 2L, 3L, 1L), displayAssignments(assignments, settings).map { it.id })
    }

    @Test fun completedOnlyListCanBeHiddenAndRestored() {
        val completed = assignments.filter { it.completed }
        assertTrue(displayAssignments(completed, PlannerSettings()).isEmpty())
        assertEquals(completed, displayAssignments(completed, PlannerSettings(showCompleted = true)))
    }
}
