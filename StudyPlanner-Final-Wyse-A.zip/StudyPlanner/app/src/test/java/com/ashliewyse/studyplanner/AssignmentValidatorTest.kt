package com.ashliewyse.studyplanner

import org.junit.Assert.*
import org.junit.Test

class AssignmentValidatorTest {
    @Test fun validatesCalendarDatesAndLeapYears() {
        assertTrue(AssignmentValidator.isValidDate("2028-02-29"))
        listOf("2026-02-29", "2026-04-31", "2026-13-01", "09/21/2026", "2026-9-21", "", "0000-01-01")
            .forEach { assertFalse(it, AssignmentValidator.isValidDate(it)) }
    }
    @Test fun requiresTitleCourseDateAndKnownPriority() {
        val valid = Assignment(title = "Project", course = "SDEV 264", dueDate = "2026-09-21")
        assertTrue(AssignmentValidator.isValid(valid))
        assertFalse(AssignmentValidator.isValid(valid.copy(title = "  ")))
        assertFalse(AssignmentValidator.isValid(valid.copy(course = "")))
        assertFalse(AssignmentValidator.isValid(valid.copy(priority = "Urgent")))
        assertFalse(AssignmentValidator.isValid(valid.copy(dueDate = "2026-04-31")))
    }
}
